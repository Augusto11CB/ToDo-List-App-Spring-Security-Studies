package spring.studies.todo.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityTreeHouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityTreeHouseApplication.class, args);
	}

}
